# -*- coding: utf-8 -*-
"""
ConSinGAN/models.py  —  改良版
支持：
  1) SA / Transformer 全局或按 stage 精细开关
  2) 兼容 use_self_attn / use_self_attention 两种命名
  3) 与原工程训练/推理接口保持一致
"""

import math
import copy
from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------
# Utils
# ---------------------------

def get_activation(opt):
    act_name = getattr(opt, "activation", getattr(opt, "act", "lrelu"))
    act_name = (act_name or "lrelu").lower()
    lrelu_alpha = float(getattr(opt, "lrelu_alpha", 0.05))
    table = {
        "relu": nn.ReLU(inplace=True),
        "lrelu": nn.LeakyReLU(lrelu_alpha, inplace=True),
        "tanh": nn.Tanh(),
        "gelu": nn.GELU(),
        "silu": nn.SiLU(inplace=True),
        "mish": nn.Mish(),
        "identity": nn.Identity(),
    }
    return table.get(act_name, nn.LeakyReLU(lrelu_alpha, inplace=True))


def _maybe_bn(num_features: int, opt, generator=True):
    """按 opt.batch_norm 选择是否插入 BatchNorm2d，默认启用"""
    use_bn = bool(getattr(opt, "batch_norm", True))
    return nn.BatchNorm2d(num_features) if use_bn else nn.Identity()


def _sa_enabled_for_stage(opt, stage_idx: Optional[int]) -> bool:
    """是否在当前 stage 启用 Self-Attention"""
    # 兼容两种命名
    use_sa = bool(getattr(opt, "use_self_attn", False) or getattr(opt, "use_self_attention", False))
    if not use_sa:
        return False
    stages = getattr(opt, "self_attention_stages", None)
    if stages is None or len(stages) == 0:
        return True  # 未指定列表 => 全开
    return (stage_idx in set(stages)) if stage_idx is not None else True


def _tr_enabled_for_stage(opt, stage_idx: Optional[int]) -> bool:
    """是否在当前 stage 启用 Transformer"""
    use_tr = bool(getattr(opt, "use_transformer", False))
    if not use_tr:
        return False
    stages = getattr(opt, "transformer_stages", None)
    if stages is None or len(stages) == 0:
        return True
    return (stage_idx in set(stages)) if stage_idx is not None else True


# ---------------------------
# Layers
# ---------------------------

class SelfAttention2d(nn.Module):
    """
    标准 2D 自注意力（与常见 SAGAN 风格兼容）
    输入: (N, C, H, W)
    """
    def __init__(self, in_channels: int):
        super().__init__()
        self.query = nn.Conv2d(in_channels, in_channels // 8, 1, bias=False)
        self.key   = nn.Conv2d(in_channels, in_channels // 8, 1, bias=False)
        self.value = nn.Conv2d(in_channels, in_channels, 1, bias=False)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        if torch.rand(1).item() < 0.05:  # 随机抽样打印，避免刷屏
            print(f"[SA Active] input={x.shape}")
        n, c, h, w = x.shape
        q = self.query(x).view(n, -1, h * w)           # (N, Cq, HW)
        k = self.key(x).view(n, -1, h * w)             # (N, Ck, HW)
        v = self.value(x).view(n,  c, h * w)           # (N, C , HW)

        attn = torch.bmm(q.transpose(1, 2), k)         # (N, HW, HW)
        attn = F.softmax(attn / math.sqrt(k.size(1) + 1e-8), dim=-1)
        out  = torch.bmm(v, attn.transpose(1, 2))      # (N, C, HW)
        out  = out.view(n, c, h, w)
        return self.gamma * out + x


class TransformerBlock(nn.Module):
    """
    简化版 Spatial Transformer：
    - 把 (N,C,H,W) 展平成 (HW, N, C)，用 MHA 做注意力后再 MLP
    - 维度: embed_dim = C, num_heads 自动从 C 里整除取 min(8, C//32 or 1)
    """
    def __init__(self, dim: int, mlp_ratio: float = 2.0):
        super().__init__()
        heads = max(1, min(8, dim // 32))
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = nn.MultiheadAttention(embed_dim=dim, num_heads=heads, batch_first=False)
        self.norm2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, dim),
        )

    def forward(self, x):
        if torch.rand(1).item() < 0.05:
            print(f"[Transformer Active] input={x.shape}")
        # x: (N,C,H,W) -> (HW, N, C)
        n, c, h, w = x.shape
        y = x.permute(2, 3, 0, 1).contiguous().view(h * w, n, c)  # (HW,N,C)
        y2 = self.attn(self.norm1(y), self.norm1(y), self.norm1(y))[0] + y
        y3 = self.mlp(self.norm2(y2)) + y2
        out = y3.view(h, w, n, c).permute(2, 3, 0, 1).contiguous()
        return out


class ConvBlock(nn.Module):
    """
    一个卷积块: Conv2d -> (BN) -> Act -> (SelfAttention2d*)
    是否加入 Self-Attention 由 opt 和当前 stage 决定
    """
    def __init__(self, in_channel, out_channel, kernel_size, padd_size, opt, generator=True):
        super(ConvBlock, self).__init__()
        self.opt = opt
        self.conv = nn.Conv2d(in_channel, out_channel, kernel_size, 1, padd_size)
        self.norm = _maybe_bn(out_channel, opt, generator=generator)
        self.act  = get_activation(opt)

        # 根据当前构建的 stage 决定是否插入 SA
        stage_idx = getattr(opt, "_current_stage", None)
        if _sa_enabled_for_stage(opt, stage_idx):
            self.self_attn = SelfAttention2d(out_channel)
        else:
            self.self_attn = None

    def forward(self, x):
        x = self.conv(x)
        x = self.norm(x)
        x = self.act(x)
        if self.self_attn is not None:
            x = self.self_attn(x)
        return x


class ResidualBlock(nn.Module):
    """简易 ResBlock（保持形状不变）"""
    def __init__(self, ch: int, opt):
        super().__init__()
        k = getattr(opt, "ker_size", getattr(opt, "kernel_size", 3))
        p = getattr(opt, "padd_size", 0)
        self.b1 = ConvBlock(ch, ch, k, p, opt, generator=True)
        self.b2 = ConvBlock(ch, ch, k, p, opt, generator=True)

    def forward(self, x):
        return x + self.b2(self.b1(x))


# ---------------------------
# Discriminator (兼容原接口)
# ---------------------------

class Discriminator(nn.Module):
    def __init__(self, opt):
        super(Discriminator, self).__init__()
        N = int(getattr(opt, "nfc", 64))
        k = int(getattr(opt, "ker_size", getattr(opt, "kernel_size", 3)))
        p = int(getattr(opt, "padd_size", 0))
        nc = int(getattr(opt, "nc_im", 3))

        self.head = ConvBlock(nc, N, k, p, opt, generator=False)
        self.body = nn.Sequential(
            ConvBlock(N, N, k, p, opt, generator=False),
            ConvBlock(N, N, k, p, opt, generator=False),
        )
        self.tail = nn.Conv2d(N, 1, k, 1, p)

    def forward(self, x):
        x = self.head(x)
        x = self.body(x)
        x = self.tail(x)
        return x


# ---------------------------
# Generator (Growing)
# ---------------------------

class GrowingGenerator(nn.Module):
    """
    与原工程保持相同的调用方式：
      forward(noises, real_shapes, noise_amp)

    差异：
      1) 不再 deepcopy 上一个 stage；而是每个 stage 现建，
         从而可以按 stage 精细控制 SA/Transformer
      2) opt 支持 self_attention_stages / transformer_stages 两个列表
    """
    def __init__(self, opt):
        super(GrowingGenerator, self).__init__()
        # 兼容字段命名
        if not hasattr(opt, "use_self_attn") and hasattr(opt, "use_self_attention"):
            opt.use_self_attn = bool(getattr(opt, "use_self_attention"))
        if not hasattr(opt, "activation") and hasattr(opt, "act"):
            opt.activation = opt.act

        self.opt = opt
        self.nc_im = int(getattr(opt, "nc_im", 3))
        self.N = int(getattr(opt, "nfc", 64))
        self.k = int(getattr(opt, "ker_size", getattr(opt, "kernel_size", 3)))
        self.p = int(getattr(opt, "padd_size", 0))

        # head / tail 与原实现保持一致
        self.head = ConvBlock(self.nc_im, self.N, self.k, self.p, self.opt, generator=True)
        self.tail = nn.Sequential(
            nn.Conv2d(self.N, self.nc_im, self.k, 1, self.p),
            nn.Tanh()
        )

        # 用 ModuleList 持有各个 stage 的 body
        self.body = nn.ModuleList()

        # 先构建 stage-0
        self.body.append(self._build_stage(stage_idx=0, N=self.N))

    # --------- 构建一个 stage 的骨架（允许按 stage 决定 SA/Transformer） ---------
    def _build_stage(self, stage_idx: int, N: int) -> nn.Sequential:
        # 标记当前正在构建的 stage，供 ConvBlock 判断是否插 SA
        self.opt._current_stage = stage_idx

        seq = nn.Sequential()
        num_layer = int(getattr(self.opt, "num_layer", 3))
        for i in range(num_layer):
            seq.add_module(f"block{i}", ConvBlock(N, N, self.k, self.p, self.opt, generator=True))

        if _tr_enabled_for_stage(self.opt, stage_idx):
            seq.add_module("transformer", TransformerBlock(N))

        return seq

    # --------- 训练时用于增加一个更细的 stage ----------
    def init_next_stage(self):
        next_idx = len(self.body)
        self.body.append(self._build_stage(stage_idx=next_idx, N=self.N))

    # --------- 前向传播 ----------
    def forward(self, noises: List[torch.Tensor], real_shapes: List[tuple], noise_amp: Optional[List[torch.Tensor]]):
        """
        noises:      [z_0, z_1, ..., z_{N-1}] ，每层一个 (1,C,H,W)
        real_shapes: [(1,C,H,W), ...]          与金字塔各层目标尺寸一致
        noise_amp:   [amp_0, amp_1, ...]
        """
        x = torch.zeros_like(noises[0])

        # head 先把第 0 层处理一下（与原工程一致）
        # 注意：我们遵循“逐层：上采样->加噪->stage->...”的范式
        for idx in range(len(self.body)):
            tgt_h, tgt_w = real_shapes[idx][2], real_shapes[idx][3]
            if x.shape[-2:] != (tgt_h, tgt_w):
                x = F.interpolate(x, size=(tgt_h, tgt_w), mode="bilinear", align_corners=False)

            z = noises[idx]
            amp = float(noise_amp[idx].detach().cpu().numpy()) if (noise_amp is not None and idx < len(noise_amp)) else 1.0

            if idx == 0:
                x = self.head(z * amp + x)
                x = self.body[idx](x)
            else:
                x = self.body[idx](x + z * amp)

        x = self.tail(x)
        return x


# 为向后兼容，部分代码中可能引用以下别名类名
Discriminator_exp = Discriminator
Generator = GrowingGenerator
Generator_exp = GrowingGenerator
